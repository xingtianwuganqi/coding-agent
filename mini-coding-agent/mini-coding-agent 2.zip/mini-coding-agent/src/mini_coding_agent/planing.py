from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING
from .evidence import (
    EvidenceType
)
from .evidence import (
    has_valid_evidence
)

from .agent_metrics import(
    AgentMetrics
)

from .tool_result import ToolResult
from .requirements import (
    RequirementState,
    build_requirement_context,
)
from .goal import GoalState
from copy import deepcopy
from .failure_recovery import clear_failure_streak

if TYPE_CHECKING:
    from .verification import VerificationRecord

# 最大停滞转数
MAX_STAGNANT_TURNS = 5

#最大重新计划数
MAX_REPLANS = 5

class PlanStatus(str, Enum):
    ACTIVE = "ACTIVE"
    SUPERSEDED = "superseded"
    COMPLETED = "completed"


@dataclass
class PlanSnapshot:
    revision: int
    items: list[TodoItem]
    status: PlanStatus
    reason: str
    created_turn: int
    superseded_turn: int | None = None


@dataclass
class PlanState:
    revision: int = 0
    # 当前的plan
    items: list[TodoItem] = field(
        default_factory=list
    )
    # history plan
    history: list[PlanSnapshot] = field(
        default_factory=list
    )

    replan_count: int = 0

@dataclass
class FailureState:
    '''
    故障状态
    '''
    last_signature: str | None = None
    consecutive_count: int = 0

@dataclass
class VerificationState:
    '''
    验证状态
    '''
    records: list[VerificationRecord] = field(
        default_factory=list
    )

class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    BLOCKED = "blocked"


@dataclass
class TodoItem: 
    id: int
    content: str
    status: TaskStatus = TaskStatus.PENDING
    note: str = ''
    required_evidence: EvidenceType | None = None

class ReplanReason(str, Enum):
    # 原计划建立在错误的认识上
    ASSUMPTION_INVALID = "assumption_invalid"
    # 当前Todo走不通
    BLOCKED_TASK = "blocked_task"
    # 重试多次失败
    REPEATED_FAILURE = "repeated_failure"
    # 当前plan导致不停调查，没有进展
    STAGNATION = "stagnation"
    # 原计划如果继续执行，就会违反 Requirement
    REQUIREMENT_CONFLICT = "requirement_conflict"

@dataclass
class AgentState:
    goal: GoalState
    plan: PlanState
    # todos: list[TodoItem] = field(default_factory=list)
    # evidence: set[EvidenceType] = field(
    #     default_factory=set
    # )
    evidence: dict[EvidenceType, int] = field(
            default_factory=dict
        )
    # Versioned Evidence, → 任何文件修改都增加
    workspace_revision: int = 0
    task_summary: str = ""
    # 预计划检查次数
    pre_plan_inspection_count: int = 0
    # 连续检索次数
    consecutive_retrieval_count: int = 0
    # 最近调用的工具
    recent_tool_calls: list[str] = field(
        default_factory=list
    )

    # 最近一次真正取得进展，是第几个 Model Turn。
    last_progress_turn: int = 0

    stagnation_warnings: int = 0

    # 记录同一个错误时不时连续失败
    failure: FailureState = field(
        default_factory=FailureState
    )

    # verification 只有代码文件修改才增加
    code_revision: int = 0
    
    changed_files: set[str] = field(
        default_factory=set
    )

    verification: VerificationState = field(
        default_factory=VerificationState
    )

    requirements: RequirementState = field(
        default_factory=RequirementState
    )

def create_agent_state(
    user_prompt: str,
) -> AgentState:
    """
    创建AgentState
    """
    return AgentState(
        goal=GoalState(
            original_request=user_prompt
        ),
        plan=PlanState()
    )


def format_plan(state: AgentState) -> str:
    if not state.plan.items:
        return "No plan"

    symbols = {
        TaskStatus.PENDING: "[ ]",
        TaskStatus.IN_PROGRESS: "[>]",
        TaskStatus.COMPLETED: "[v]",
        TaskStatus.BLOCKED: "[!]",
    }

    lines = []
    for todo in state.plan.items:
        line = (
            f"{symbols[todo.status]} "
            f"{todo.id}. {todo.content}"
        )

        if (
            todo.required_evidence is not None
        ):
            line += (
                " "
                "[requires: "
                f"{todo.required_evidence.value}"
                "]"
            )

        if todo.note:
            line += f" - {todo.note}"

        lines.append(line)

    return "\n".join(lines)

# set_plan 从之前的list[str]改为list[dict]，其中携带了是否需要验证
def set_plan(
        state: AgentState,
        items: list[dict]
) -> ToolResult:
    """
    设置计划
    """

    # Goal 必须确定
    if not state.goal.locked:
        return ToolResult.fail(
            error=(
                "Goal must be locked "
                "before creating a plan"
            )
        )

    # Requirement必须确定
    if not state.requirements.locked:
        return ToolResult.fail(
            error=(
                "Requirements must be locked "
                "before creating a plan"
            )
        )
    # 已经有plan 
    if state.plan.revision > 0:
        return ToolResult.fail(
            error=(
                "An active plan already exists. "
                "Use replan instead of set_plan."
            )
        )

    # plan不能为空
    clean_items = [
        item
        for item in items
        if item
    ]

    if not clean_items:
        return ToolResult.fail(
            error="Plan cannot be empty."
        )

    # old_plan = [
    #     {
    #         "content": todo.content,
    #         "required_evidence": (
    #             todo.required_evidence.value
    #             if todo.required_evidence
    #             else "none"
    #         )
    #     }
    #     for todo in state.todos
    # ]
    # if old_plan == items:
    #     return ToolResult.fail(
    #         error="Plan is unchanged",
    #     )
    # Plan v1
    todos = []
    for index, item in enumerate(
        items,
        start=1
    ): 
        evidence_value = item.get(
            "required_evidence", "none"
        )

        required_evidence = None
        if evidence_value != "none":
            try:
                required_evidence = EvidenceType(
                    evidence_value
                )

            except ValueError:
                return ToolResult(
                    success=False,
                    error=(
                        f"Invalid evidence type:"
                        f"{evidence_value}"
                    )
                )

        todos.append(
            TodoItem(
                id=index,
                content=item["content"],
                required_evidence=required_evidence
            )
        )

    state.plan.revision = 1
    state.plan.items = todos

    return ToolResult(
        success=True,
        content=format_plan(state),
    )

def replan(
        state: AgentState,
        items: list[dict],
        reason: ReplanReason,
        explanation: str, # 解释
        current_turn: int,
) -> ToolResult:

    if (state.plan.replan_count >= MAX_REPLANS):
        return ToolResult.fail(
            error=(
                "Maximum replanning limit "
                "has been reached. "
                "Do not keep replacing the plan. "
                "Resolve the current blocker or "
                "mark the task blocked."
            )
        )

    # 必须有plan
    if state.plan.revision == 0:
        return ToolResult.fail(
            error=(
                "No existing plan."
                "Use set_plan first."
            )
        )

    # Goal / Requirements 必须保持锁定
    if not state.goal.locked:
        return ToolResult.fail(
            error="Cannot replan without a locked goal."
        )

    if not state.requirements.locked:
        return ToolResult.fail(
            "Cannot replan without locked requirements."
        )

    explanation = explanation.strip()

    if not explanation:
        return ToolResult.fail(
            error=(
                "Replanning requires an explanation."
            )
        )

    # 先校验并构造新计划，失败时不改变当前计划。
    if not items:
        return ToolResult.fail(
            "Replacement plan cannot be empty."
        )

    todos = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict) or not isinstance(item.get("content"), str):
            return ToolResult.fail(error="Plan item must have text content.")

        content = item["content"].strip()
        if not content:
            return ToolResult.fail(error="Plan item content cannot be empty.")

        evidence_value = item.get("required_evidence", "none")
        required_evidence = None
        if evidence_value != "none":
            try:
                required_evidence = EvidenceType(evidence_value)
            except ValueError:
                return ToolResult.fail(
                    error=f"Invalid evidence type: {evidence_value}"
                )

        todos.append(
            TodoItem(
                id=index,
                content=content,
                required_evidence=required_evidence,
            )
        )

    # 不允许完全相同的plan
    old_contents = [
        item.content
        for item in state.plan.items
    ]

    if old_contents == [item.content for item in todos]:
        return ToolResult.fail(
            error=(
                "Replacement plan is identical to the current plan."
            )
        )

    # 保存旧plan
    old_revision = state.plan.revision
    snapshot = PlanSnapshot(
        revision=old_revision,
        items = deepcopy(
            state.plan.items
        ),
        status=PlanStatus.SUPERSEDED,
        reason=(
            f"{reason.value}"
            f"{explanation}"
        ),
        created_turn=0,
        superseded_turn=current_turn
    )
    new_revision = old_revision + 1
    state.plan.history.append(snapshot)
    state.plan.revision = new_revision
    state.plan.items = todos
    state.plan.replan_count += 1
    # 清空所有的failure streak
    clear_failure_streak(state=state)
    record_progress(state=state, turn=current_turn)

    return ToolResult.ok(
        content=(
            f"Plan revision "
            f"{old_revision} was superseded."
            f"Created plan revision "
            f"{new_revision}."
        )
    )

def update_task(
        state: AgentState,
        metrics: AgentMetrics,
        task_id: int,
        status: str,
        note: str = "",
) -> ToolResult:
    """
    更新计划
    """
    try:
        new_status = TaskStatus(status)
    except ValueError:
        return ToolResult(
            success=False,
            error=f"Invalid status: {status}"
        )

    for todo in state.plan.items:
        if todo.id != task_id:
            continue

        # 如果状态相同，不用改
        if todo.status == new_status:
            return ToolResult.fail(
                error=(
                    f"Task {task_id} is already "
                    f"{new_status.value}"
                ),
            )
        # 如果当前状态完成了，
        # 如果这个 Todo 有证据要求：required = todo.required_evidence
        # 但runtime中没有记录required not in state.evidence
        # 直接拒绝
        if (new_status == TaskStatus.COMPLETED 
            and todo.required_evidence is not None 
            and not has_valid_evidence(
                state,
                todo.required_evidence
            )
        ):
            return ToolResult(
                success=False,
                error=(
                    f"Cannot complete task "
                    f"{task_id}.\n"
                    f"Required evidence is missing: "
                    f"{todo.required_evidence.value}"
                )
            )

        # 只有状态真正发生改变的时候才记录
        if todo.status != new_status:
            record_progress(
                state=state,
                turn=metrics.model_turns
            )
        todo.status = new_status

        if note:
            todo.note = note

        result = format_plan(state)

        print("\n--- Current Plan ---")
        print(result)

        return ToolResult(
            success=True,
            content=result,
        )

    return ToolResult(
        success=False,
        error=f"Task not found: {task_id}"
    )


def get_plan(
        state: AgentState
) -> ToolResult:
    """
    获取计划
    """
    return ToolResult(
        success=True,
        content=format_plan(state)
    )

def print_state_debug(
    state: AgentState,
) -> None:
    print("\n--- Runtime State ---")

    print(
        "Workspace revision:",
        state.workspace_revision,
    )

    print("Evidence:")

    if not state.evidence:
        print("  (none)")
        return

    for evidence_type, revision in (
        state.evidence.items()
    ):
        valid = (
            revision
            == state.workspace_revision
        )

        print(
            f"  {evidence_type.value}: "
            f"revision={revision}, "
            f"valid={valid}"
        )


def record_progress(
        state: AgentState,
        turn: int,
) -> None:
    state.last_progress_turn = turn
    state.stagnation_warnings = 0


def tool_caused_progress(
    name: str,
    result: ToolResult,
) -> bool:
    '''
    判断“这次工具调用成功了，但它到底算不算真正推进了任务”。
    '''
    if not result.success:
        return False

    progress_tools = {
        "write_file",
        "replace_text",
        "set_plan",
        "update_task",
    }

    return name in progress_tools


def is_stagnating(
        state: AgentState,
        current_turn: int,
) -> bool:
    '''
    判断是不是进入了停滞
    '''
    if not state.plan.items:
        return False

    stagnant_turns = (
        current_turn - state.last_progress_turn
    )

    return stagnant_turns >= MAX_STAGNANT_TURNS


def build_stagnation_feedback(
        state: AgentState,
) -> str:
    '''
    构建停滞反馈
    '''
    active_task = next(
        (
            todo 
            for todo in state.plan.items
            if todo.status
            == TaskStatus.IN_PROGRESS
        ),
        None
    )

    task_text = (
        active_task.content
        if active_task
        else "current task"
    )

    return (
        "RUNTIME NOTICE: progress has stalled. "
        "Several turns have passed without a "
        "meaningful state change. "
        f"Current task: {task_text}. "
        "Use the information already gathered "
        "to take the next concrete action. "
        "Do not continue investigating unless "
        "a specific missing fact blocks progress."
    )


def build_goal_context(
        state: AgentState
) -> str:

    if not state.goal.locked:
        return (
            "GOAL:\n"
            "Not established yet. "
        )

    return (
        "LOCKED GOAL: \n"
        f"{state.goal.objective}\n\n"
        "The goal cannot be changed "
        "during replanning"
    )


def build_plan_context(
        state: AgentState,
) -> str:

    if state.plan.revision == 0:
        return (
            "ACTIVE PLAN: \n"
            "No plan exists yet."
        )

    lines = [
        (
            "ACTIVE PLAN "
            f"[revision "
            f"{state.plan.revision}]:"
        )
    ]

    for todo in state.plan.items:
        lines.append(
            f"- [{todo.status.value}]"
            f"{todo.id}"
            f"{todo.content}"
        )

    if state.plan.replan_count > 0:
        lines.append("")
        lines.append(
            "Previous plan revisions: "
            f"{state.plan.replan_count}"
        )

    return "\n".join(lines)


def build_runtime_instructions(
        state: AgentState,
) -> str:

    parts = [
        build_goal_context(
            state
        ),
        build_requirement_context(
            state,
        ),
        build_plan_context(
            state,
        )
    ]

    return "\n\n".join(
        part 
        for part in parts
        if part
    )

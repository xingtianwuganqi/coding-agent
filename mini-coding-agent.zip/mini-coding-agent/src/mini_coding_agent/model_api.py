"""Single entry point for DeepSeek and Zhipu model requests."""

import os
import json
import time
from pathlib import Path
from openai import OpenAI
from openai.types.chat import ChatCompletionMessage


def _load_local_env() -> None:
    """Load project-local API keys without overriding exported variables."""
    env_path = Path(__file__).resolve().parents[2] / ".env"
    if not env_path.is_file():
        return

    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_local_env()

RETRY_DELAYS = tuple(5 + index for index in range(6))  # seconds

# Debug output is deliberately bounded. Printing a full model response can
# produce a single line with tens of thousands of characters, which has been
# observed to crash Terminal.app on macOS while it scans text for URLs.
DEBUG_PREVIEW_CHARS = 800


def _preview(
        text: object,
        limit: int = DEBUG_PREVIEW_CHARS,
) -> str:
    """Return a bounded single-value preview for terminal output."""
    if text is None:
        return ""

    value = str(text)

    if len(value) <= limit:
        return value

    omitted = len(value) - limit

    return (
        value[:limit]
        + f"... [truncated {omitted} chars]"
    )


class ModelCallError(RuntimeError):
    """Raised when every attempt to call the model has failed."""

# Change only this value, then restart the agent.
PROVIDER = "302"

PROVIDERS = {
    "zhipu": {
        "base_url": "https://open.bigmodel.cn/api/paas/v4/",
        "model": "glm-4.7",
        "api_key": os.getenv("ZHIPU_API_KEY"),
    },
    "deepseek": {
        "base_url": "https://api.deepseek.com",
        "model": "deepseek-flash",
        "api_key": os.getenv("DEEPSEEK_API_KEY"),
    },
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "model": "qwen/qwen3.8-27b",
        "api_key": os.getenv("GROQ_API"),
    },
    "gemini": {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
        "model": "gemini-3.5-flash",
        "api_key": os.getenv("GEMINI_API")
    },
    "openrouter": {
        "base_url": "https://openrouter.ai/api/v1",
        "model": "minimax/minimax-m3.1-flash:free",
        "api_key": os.getenv("OPENROUTER_API")
    },
    "bai": {
        "base_url": "https://api.b.ai/v1",
        "model": "deepseek-v4.1-flash",
        "api_key": os.getenv("BAI_API_KEY"),
    },
    "302": {
        "base_url": "https://api.302ai.com/v1",
        "model": "qwen3.8-flash",
        "api_key": os.getenv("302_API_KEY"),
    },
    "opencode": {
        "base_url": "https://opencode.ai/inference/openai/v1",
        "model": "deepseek-v4.1-flash-free",
        "api_key": os.getenv("OPENCODE_API")
    }
}


def call_model(
    messages: list[dict],
    *,
    instructions: str | None = None,
    tools: list[dict] | None = None,
    thinking: bool | None = None,
    debug: bool = False,
) -> ChatCompletionMessage:
    """Return one assistant message, including tool_calls and reasoning_content."""
    if PROVIDER not in PROVIDERS:
        raise ValueError(f"Unknown model provider: {PROVIDER}")
    settings = PROVIDERS[PROVIDER]
    if not settings["api_key"]:
        raise RuntimeError(
            f"Missing API key for {PROVIDER}. Set the required value in .env."
        )
    request = {"model": settings["model"], "messages": list(messages)}
    if instructions:
        request["messages"].insert(0, {"role": "system", "content": instructions})
    if tools:
        request["tools"] = [
            tool if "function" in tool else {
                "type": "function",
                "function": {key: value for key, value in tool.items() if key != "type"},
            }
            for tool in tools
        ]
    if thinking is not None:
        request["extra_body"] = {
            "thinking": {"type": "enabled" if thinking else "disabled"}
        }
    # if debug:
    #     print("\n--- Request JSON ---")
    #     print(json.dumps(request, ensure_ascii=False, indent=2), flush=True)
    with OpenAI(
        api_key=settings["api_key"],
        base_url=settings["base_url"],
        max_retries=0,
    ) as client:
        for retry_index in range(len(RETRY_DELAYS) + 1):
            try:
                response = client.chat.completions.create(**request)
                if not response.choices:
                    raise RuntimeError(f"{PROVIDER} returned no response choices")
                break
            except Exception as error:
                if retry_index == len(RETRY_DELAYS):
                    raise ModelCallError(
                        f"Model request failed after {retry_index + 1} attempts: {error}"
                    ) from error
                delay = RETRY_DELAYS[retry_index]
                print(
                    f"Model request failed ({type(error).__name__}: "
                    f"{_preview(error)}). "
                    f"Retrying in {delay}s ({retry_index + 1}/{len(RETRY_DELAYS)}).",
                    flush=True,
                )
                time.sleep(delay)
    message = response.choices[0].message
    if debug:
        print("\n--- Model Response (truncated) ---")
        if message.content:
            print("content:", _preview(message.content))
        reasoning = getattr(
            message,
            "reasoning_content",
            None,
        )
        if reasoning:
            print("reasoning:", _preview(reasoning))
        for call in (message.tool_calls or []):
            print(
                "tool_call:",
                call.function.name,
                "args:",
                _preview(call.function.arguments, 1000),
            )
        print("---------------------------------", flush=True)
    return message

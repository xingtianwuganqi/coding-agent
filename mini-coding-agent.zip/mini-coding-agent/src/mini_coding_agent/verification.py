'''验证'''

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .planning import AgentState
from .tool_result import ToolResult
from .agent_metrics import is_test_command
from .evidence import CommandResult

class VerificationKind(str, Enum):
    '''
    需要验证的类型
    '''
    # 查看修改内容
    DIFF = "diff"
    # test
    TEST = "test"
    # build
    BUILD = "build"
    # py_compile 等轻量验证
    SYNTAX = "syntax"
    # 修改后重新读取文件确认
    READBACK = "readback"

@dataclass
class VerificationRecord:
    '''
    验证记录
    '''
    kind: VerificationKind
    success: bool
    workspace_revision: int
    code_revision: int
    source: str
    detail: str


CODE_EXTENSIONS = {
    ".py",
    ".go",
    ".swift",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".java",
    ".kt",
    ".c",
    ".cc",
    ".cpp",
    ".h",
    ".hpp",
    ".rs",
}


def is_code_file(
    path: str,
) -> bool:
    """判断给定路径是否为代码文件。

    通过提取文件路径的扩展名（忽略大小写），并与 CODE_EXTENSIONS
    中登记的受支持代码后缀集合进行比对来确定结果。

    Args:
        path: 待检测的文件路径字符串。

    Returns:
        bool: 若文件扩展名属于已知代码后缀则返回 True，否则返回 False。
    """

    from pathlib import Path

    suffix = (
        Path(path)
        .suffix
        .lower()
    )

    return (
        suffix
        in CODE_EXTENSIONS
    )


def record_verification(
        state: AgentState,
        kind: VerificationRecord,
        success: bool,
        source: str,
        detail: str = ""
) -> None:
    '''
    记录验证信息到AgentState
    '''
    record = VerificationRecord(
        kind=kind,
        success=success,
        workspace_revision=state.workspace_revision,
        code_revision=state.code_revision,
        source=source,
        detail=detail
    )

    state.verification.records.append(
        record
    )


def is_diff_command(
        command: str,
) -> bool:
    '''
    判断是否git diff命令
    '''
    command = (
        command.strip().lower()
    )

    return command.startswith("git diff")


def is_build_command(
        command: str,
) -> bool:
    ''' 
    判断是否build命令
    '''
    command = command.lower()

    keywords = [
        "go build",
        "swift build",
        "npm run build",
        "pnpm build",
        "yarn build",
        "xcodebuild",
        "cargo build",
    ]

    return any(
        keyword in command
        for keyword in keywords
    )


def is_syntax_command(
    command: str,
) -> bool:
    '''
    判断是否syntax命令
    '''
    command = command.lower()

    keywords = [
        "py_compile",
        "compileall",
    ]

    return any(
        keyword in command
        for keyword in keywords
    )


def record_command_verification(
    state,
    command: str,
    result: CommandResult,
) -> None:
    '''
    记录命令验证结果
    '''
    success = (
        result.returncode == 0
    )

    detail = (
        result.stdout[-1000:]
        or result.stderr[-1000:]
    )

    if is_test_command(command):

        record_verification(
            state=state,
            kind=VerificationKind.TEST,
            success=success,
            source=command,
            detail=detail,
        )

        return

    if is_diff_command(command):

        record_verification(
            state=state,
            kind=VerificationKind.DIFF,
            success=success,
            source=command,
            detail=detail,
        )

        return

    if is_build_command(command):

        record_verification(
            state=state,
            kind=VerificationKind.BUILD,
            success=success,
            source=command,
            detail=detail,
        )

        return

    if is_syntax_command(command):

        record_verification(
            state=state,
            kind=VerificationKind.SYNTAX,
            success=success,
            source=command,
            detail=detail,
        )


def has_successful_code_verification(
    state,
) -> bool:
    '''
    是否已经state.verification的records中是否有已经记录的state.code_revision
    '''
    for record in reversed(
        state.verification.records
    ):

        if (
            record.code_revision
            != state.code_revision
        ):
            continue

        if (
            record.kind
            in {
                VerificationKind.TEST,
                VerificationKind.BUILD,
                VerificationKind.SYNTAX,
            }
            and record.success
        ):
            return True

    return False


def has_current_diff_verification(
    state,
) -> bool:
    '''
    判断是否完成了git diff
    '''
    for record in reversed(
        state.verification.records
    ):

        if (
            record.kind
            != VerificationKind.DIFF
        ):
            continue

        if (
            not record.success
        ):
            continue

        if (
            record.workspace_revision
            == state.workspace_revision
        ):
            return True

    return False
    
